package student.hello;

public interface Greeting {
    String greet();
    String greet(String who);
    void printGreeting();
}
